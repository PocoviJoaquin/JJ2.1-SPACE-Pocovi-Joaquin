import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.Timer;

public class Window extends JFrame implements Runnable, KeyListener {

    public static int WIDTH = 700, HEIGHT = 800;
    private Canvas canvas;
    private Thread thread;
    private boolean running;
    private boolean windowClosed = false; // NUEVO CAMPO PARA SEGUIMIENTO DEL ESTADO DE LA VENTANA

    private BufferStrategy bs;
    private Graphics g;

    private final int FPS = 60;
    private double TARGETTIME = 1000000000 / FPS;
    private double delta = 0;
    private int AVERAGEFPS = FPS;

    private Player player;
    private List<Enemy> enemies; // Lista de enemigos

    int cantidadDeEnemigos;

    // Variables para el control del jugador
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private boolean space = false;
    // variable control de niveles
    public int levelSelect = 1;
    public int score = 0;
    public int nivelCompletado;
    public int perder = 0;
    public static int vidas = 3;
    public static int noColisionasMasEnTodaTuPutaVida = 0;
    private Timer levelCompleteTimer; // CAMBIADO A TIMER A NIVEL DE CLASE
    Font font = new Font("Minecraft", Font.PLAIN, 20);
    Font fontLargo = new Font("Minecraft", Font.PLAIN, 40);
    private BufferedImage lifeImage;
    
    public Window() {
        setTitle("Galaga Invaders");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        canvas.setMaximumSize(new Dimension(WIDTH, HEIGHT));
        canvas.setMinimumSize(new Dimension(WIDTH, HEIGHT));
        canvas.setFocusable(true);

        add(canvas);
        canvas.addKeyListener(this); // Añadir el KeyListener al canvas
        
        try {
            lifeImage = ImageIO.read(getClass().getResource("/images/cora_verde.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se pudo cargar la imagen de vida.");
        }

        player = new Player(WIDTH / 2 - 50, HEIGHT - 100, 80, 40, 6, Color.blue);

        enemies = new ArrayList<>();
        int y = 0, z = 0;
        for (int i = 0; i < 30; i++) {
            if (i < 10) {
                enemies.add(new Enemy(i * 50, 120, 30, 30, 2, Color.RED, player));
            } else if (i < 20) {
                enemies.add(new Enemy(y * 50, 170, 30, 30, 2, Color.RED, player));
                y++;
            } else if (i < 30) {
                enemies.add(new Enemy(z * 50, 220, 30, 30, 2, Color.RED, player));
                z++;
            }
        }

        cantidadDeEnemigos = enemies.size();
        
        
    }

    private void update() {
    	
    	if(vidas == 0) {
    		if(perder != 2) {
        		perder = 1;
    		}

    		noColisionasMasEnTodaTuPutaVida = 1; 
    	}
    	
        if (levelSelect == 1) {
            player.update(leftPressed, rightPressed, space, enemies);
            for (Enemy enemy : enemies) {
                enemy.update(enemies);
            }
            // Eliminar enemigos que hayan sido impactados por balas
            for (int i = enemies.size() - 1; i >= 0; i--) {
                Enemy enemy = enemies.get(i);
                if (!enemy.isAlive()) {
                    enemies.remove(i);
                    score += 10;
                    cantidadDeEnemigos--;
                }
            }

            // Chequear colisiones y cambiar dirección si es necesario
            for (Enemy enemy : enemies) {
                if (enemy.getX() + enemy.getWidth() >= Window.WIDTH - 15 || enemy.getX() <= 0) {
                    todosCaen(); // todos cambian de dirección y descienden

                    // Aumentar la velocidad de todos los enemigos
                    for (Enemy e : enemies) {
                        e.aumentarVelocidad();
                    }

                    break;
                }
            }
        }

        // En el caso de que ya no queden más enemigos de la lista que se termine el juego
        if (cantidadDeEnemigos == 0) {
            if (levelCompleteTimer == null || !levelCompleteTimer.isRunning()) {
                nivelCompletado = 1;
                cantidadDeEnemigos = 30; // Reinicia la cantidad de enemigos si es necesario

                // Inicializa el Timer para esperar 3 segundos antes de cerrar la ventana
                levelCompleteTimer = new Timer(3000, e -> {
                    // DETENER EL TIMER ANTES DE CERRAR LA VENTANA
                    if (levelCompleteTimer != null && levelCompleteTimer.isRunning()) {
                        levelCompleteTimer.stop();
                    }
                    // Cerrar la ventana actual
                    windowClosed = true; // MARCAR LA VENTANA COMO CERRADA
                    this.dispose();
               
                    // Iniciar la nueva ventana de menú después de cerrar la actual
                    new Menu_Level().start();
                });
                levelCompleteTimer.setRepeats(false); // Hacer que el Timer se ejecute solo una vez
                levelCompleteTimer.start();
                
                
            }
        }
        
        
        if (vidas == 0 && perder == 1) {
             cantidadDeEnemigos = 30; // Reinicia la cantidad de enemigos si es necesario
            perder++;
            System.out.println("Se mete al if de cerrar");
            // Inicializa el Timer para esperar 3 segundos antes de cerrar la ventana
            levelCompleteTimer = new Timer(3000, e -> {
                // DETENER EL TIMER ANTES DE CERRAR LA VENTANA
                if (levelCompleteTimer != null && levelCompleteTimer.isRunning()) {
                    levelCompleteTimer.stop();
                    
                }
                // Cerrar la ventana actual
                windowClosed = true; // MARCAR LA VENTANA COMO CERRADA
                this.dispose();
                   
                // Iniciar la nueva ventana de menú después de cerrar la actual
                new Menu_Level().start();
                
            });
            levelCompleteTimer.setRepeats(false); // Hacer que el Timer se ejecute solo una vez
            levelCompleteTimer.start();
        }
        
    }

    private void draw() {
        if (windowClosed) { // COMPROBAR SI LA VENTANA ESTÁ CERRADA
            return;
        }

        bs = canvas.getBufferStrategy();

        if (bs == null) {
            canvas.createBufferStrategy(3);
            return;
        }

        g = bs.getDrawGraphics();

        g.setColor(Color.black);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        // Dibujar al jugador
        player.draw(g);

        // Dibujar enemigos
        for (Enemy enemy : enemies) {
            enemy.draw(g);
        }
        
     // Dibujar barrera piola
        // b1
        if(Enemy.levelSelect > 1 && Enemy.levelSelect <= 5) {
            g.setColor(Color.green); // Color azul piola para la barrera
            g.fillRect(WIDTH/3-175, (HEIGHT-HEIGHT/3), 100, 30);

            // b2
            g.setColor(Color.green); // Color azul piola para la barrera
            g.fillRect((WIDTH/2)-60, (HEIGHT-HEIGHT/3), 100, 30);
            
            
            // b3
            g.setColor(Color.green); // Color azul piola para la barrera
            g.fillRect((WIDTH/3-60)*3, (HEIGHT-HEIGHT/3), 100, 30);
            
            // falta realizar la logica para que funcione la barrera y que su integridad disminuya        	
        }

        
        

        // puntuación
        g.setFont(font);
        g.setColor(Color.green);
        g.drawString("Puntuacion: " + score, 20, 50); 

        // nivel seleccionado
    
        g.setFont(font);
        g.setColor(Color.white);
        
        if(Enemy.levelSelect == 1) {
        	g.drawString("Nivel 1",WIDTH/2-28, 50);   
        }
        
        else if(Enemy.levelSelect == 2) {
        	g.drawString("Nivel 2",WIDTH/2-28, 50);  
        }
        
        else if(Enemy.levelSelect == 3) {
        	g.drawString("Nivel 3",WIDTH/2-28, 50);  
        }
        
        else if(Enemy.levelSelect == 4) {
        	g.drawString("Nivel 4",WIDTH/2-28, 50);  
        }
        
        else if(Enemy.levelSelect == 5) {
        	g.drawString("Nivel 5",WIDTH/2-28, 50);  
        }
        
        // enemigos restantes
        g.setFont(font);
        g.setColor(Color.green);
        g.drawString("Restantes: " + cantidadDeEnemigos, WIDTH - 165, 50);

        // si gana muestra este mensaje para aquello la variable de nivelCompletado debe ser igual a 1
        if (nivelCompletado == 1) {
            g.setFont(fontLargo);
            g.setColor(Color.blue);
            g.drawString("NIVEL COMPLETADO", (WIDTH / 2) - 215, HEIGHT / 2);
        }
        
        
        // dibujar vidas
        if (vidas > 0) {
            int startX = 20; // Posición X inicial para dibujar las vidas
            int startY = 70; // Posición Y para dibujar las vidas
            int lifeWidth = 35; // Ancho de la imagen de vida
            int lifeHeight = 35; // Alto de la imagen de vida
            int spacing = 10; // Espaciado entre las imágenes de vidas

            for (int i = 0; i < vidas; i++) {
                g.drawImage(lifeImage, startX + (i * (lifeWidth + spacing)), startY, lifeWidth, lifeHeight, null);
            }
        }
        
        
        // si perdes muestra este mensaje para aquello la varible de vidas debe ser igual a 0
        if(vidas == 0) {
            g.setFont(fontLargo);
            g.setColor(Color.red);
            g.drawString("GAME OVER", (WIDTH / 2) - 115, HEIGHT / 2);     
        }

        g.dispose();
        bs.show();
    }

    @Override
    public void run() {
        long now = 0;
        long lastTime = System.nanoTime();
        int frames = 0;
        long time = 0;

        while (running) {
            now = System.nanoTime();
            delta += (now - lastTime) / TARGETTIME;
            time += (now - lastTime);
            lastTime = now;

            if (delta >= 1) {
                update();
                draw();
                delta--;
                frames++;
            }

            if (time >= 1000000000) {
                AVERAGEFPS = frames;
                frames = 0;
                time = 0;
            }
        }

        stop();
    }

    public void start() {
        thread = new Thread(this);
        thread.start();

        running = true;
    }

    private void stop() {
        try {
            thread.join();
            running = false;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            leftPressed = true;
        }
        if (key == KeyEvent.VK_RIGHT) {
            rightPressed = true;
        }

        if (key == KeyEvent.VK_SPACE) {
            space = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            leftPressed = false;
        }
        if (key == KeyEvent.VK_RIGHT) {
            rightPressed = false;
        }

        if (key == KeyEvent.VK_SPACE) {
            space = false;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    public void todosCaen() {
        // Cambiar dirección y hacer descender a todos los enemigos
        for (Enemy enemy : enemies) {
            enemy.cambiarDireccion(true);
            enemy.descender(); // Nuevo método para hacer que todos desciendan
        }
    }
}
