import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Enemy {

    private int x, y;
    private int width, height;
    private float speed;
    private Color color;
    
    private boolean direccionDerecha = true; // Indica la dirección de movimiento
    private boolean isAlive = true; // Variable para el estado del enemigo
    
    private Image image;
    
    public Enemy(int x, int y, int width, int height, float speed, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.color = color;        
        this.isAlive = true;
    
        try {
            image = ImageIO.read(getClass().getResource("/images/NaveInvasoraRoja.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se pudo cargar la imagen del enemigo.");
        }
    }
    
    public void draw(Graphics g) {
        if (isAlive) {
            if (image != null) {
                g.drawImage(image, x, y, width, height, null); // Dibuja la imagen del enemigo
            } else {
                // Si no se carga la imagen, dibujar un rectángulo de color como fallback
                g.setColor(color);
                g.fillRect(x, y, width, height);
            }
        }
    }
    
    public void update() {
        if (isAlive) {
            if (direccionDerecha) {
                x += speed;
            } else {
                x -= speed;
            }
        }
    }
    
    public void die() {
        isAlive = false; // Marcar al enemigo como muerto
    }
    
    public boolean isAlive() {
        return isAlive;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public void cambiarDireccion(boolean aux) {
        direccionDerecha = !direccionDerecha;
    }
    
    public void descender() {
        y += 10; 
    }
    
    public void aumentarVelocidad() {
        this.speed *= 1.0234; // 
    }
}
