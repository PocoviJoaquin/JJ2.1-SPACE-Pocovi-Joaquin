import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;

public class Level1 extends JFrame {
    private Player player;
    private List<Enemy> enemies; // Lista de enemigos

    // Variables para el control del jugador
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private boolean space = false;

    public Level1() {
        // Configurar la ventana del nivel
        setTitle("Level 1");
        setSize(Window.WIDTH, Window.HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        // Inicializar jugador
        player = new Player(Window.WIDTH / 2 - 50, Window.HEIGHT - 100, 100, 50, 10, Color.blue);

        // Inicializar enemigos
        enemies = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            enemies.add(new Enemy(i * 100, 50, 50, 50, 5, Color.RED));
        }

        setVisible(true);
    }

    // Quita el modificador 'static' de update()
    public void update() {
        player.update(leftPressed, rightPressed, space, enemies);
        for (Enemy enemy : enemies) {
            enemy.update();
        }
        // Eliminar enemigos que hayan sido impactados por balas
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy enemy = enemies.get(i);
            if (!enemy.isAlive()) {
                enemies.remove(i);
            }
        }
    }

    // Métodos para manejar la entrada de teclado
    public void setLeftPressed(boolean pressed) {
        leftPressed = pressed;
    }

    public void setRightPressed(boolean pressed) {
        rightPressed = pressed;
    }

    public void setSpacePressed(boolean pressed) {
        space = pressed;
    }
}
