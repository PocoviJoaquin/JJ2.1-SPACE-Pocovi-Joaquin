import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;

public class Player {
    public static int x, y;
    private int width, height;
    private int speed;
    private Color color;
    private List<BulletPlayer> bullets; // array de balas basicamente
    
    private long lastShotTime = 0; // Tiempo del último disparo
    private final long COOLDOWN = 150; // Tiempo de espera entre disparos (milisegundos)
    
    private Image image; // Imagen del jugador

    public Player(int x, int y, int width, int height, int speed, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.color = color;
        this.bullets = new ArrayList<>();
        
        // Cargar la imagen del jugador
        try {
            image = ImageIO.read(getClass().getResource("/images/Player.png")); // Asegúrate de que el archivo está en esta ruta
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se pudo cargar la imagen del jugador.");
        }
    }

    public void draw(Graphics g) {
        if (image != null) {
            g.drawImage(image, x, y, width, height, null); // Dibuja la imagen del jugador
        } else {
            g.setColor(color);
            g.fillRect(x, y, width, height); // Dibuja un rectángulo de color como fallback
        }
        
        // Dibujar las balas
        for (BulletPlayer bullet : bullets) {
            bullet.draw(g);
        }
    }

    public void update(boolean left, boolean right, boolean space, List<Enemy> enemies) {
        if (left) {
            x -= speed;
        }
        if (right) {
            x += speed;
        }
        
        long currentTime = System.currentTimeMillis();
        if ((space && (currentTime - lastShotTime >= COOLDOWN))) {
            shoot();
            lastShotTime = currentTime; // Actualizar el tiempo del último disparo
        }
        
        // Limitar la posición dentro de los límites de la ventana
        if (x < 5 ) {
            x = 5;
        }
        if (x + width + 25 > Window.WIDTH) {
            x = Window.WIDTH - width - 25;
        }
        
        // Actualizar todas las balas y eliminar las que están fuera de la pantalla
        List<BulletPlayer> bulletsToRemove = new ArrayList<>();
        for (BulletPlayer bullet : bullets) {
            bullet.update();
            if (bullet.getY() < 0) {
                bulletsToRemove.add(bullet);
            }
            
            for (Enemy enemy : enemies) {
                if (enemy.isAlive() &&
                    bullet.getY() < enemy.getY() + enemy.getHeight() &&
                    bullet.getY() + bullet.getHeight() > enemy.getY() &&
                    bullet.getX() < enemy.getX() + enemy.getWidth() &&
                    bullet.getX() + bullet.getWidth() > enemy.getX()) {
                    enemy.die(); // Marcar al enemigo como muerto
                    bulletsToRemove.add(bullet); 
                }
            }
        }
        bullets.removeAll(bulletsToRemove);
    }
    
    private void shoot() {
        // Crear una nueva bala y añadirla a la lista de balas
        BulletPlayer bullet = new BulletPlayer(x + width / 2 - 2, y, 5, 5, 8, Color.green);
        bullets.add(bullet);
    }
    
    // Getters y setters (opcional si necesitas acceder a estas variables)
    public static int getX() { return x; }
    public static int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getSpeed() { return speed; }

}
