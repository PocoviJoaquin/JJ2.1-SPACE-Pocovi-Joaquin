import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Kamikaze {

    private int x, y;
    private int width, height;
    private float speed;
    private Color color;
    
    private boolean direccionDerecha = true; // Indica la dirección de movimiento
    private boolean isAlive = true; // Variable para el estado del enemigo
    private boolean launched;
    
    private Image image;
    
    public Kamikaze(int x, int y, int width, int height, float speed, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.color = color;        
        this.isAlive = true;
        this.launched = false;
    
        try {
            image = ImageIO.read(getClass().getResource("/images/NaveInvasoraRoja.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se pudo cargar la imagen del enemigo.");
        }
    }
    
    public void draw(Graphics g) {
        if (isAlive) {
            if (image != null) {
                g.drawImage(image, x, y, width, height, null); // Dibuja la imagen del enemigo
            } else {
                // Si no se carga la imagen, dibujar un rectángulo de color como fallback
                g.setColor(color);
                g.fillRect(x, y, width, height);
            }
        }
    }
    
    public void update() {
        if(!launched) return;
        int playerX = Player.getX();
        int playerY = Player.getY();

        if (isAlive) {
            int deltaX = playerX - x;
            int deltaY = playerY - y;

            // Calcular una probabilidad de movimiento errático basada en la distancia vertical
            double erraticFactor = Math.min(1, (double)Math.abs(deltaY) / 500.0); 
            // '400.0' es un valor ajustable que determina a qué distancia vertical el movimiento errático se reduce

            if (Math.random() < erraticFactor) {
                // Movimiento errático: cambiar la dirección horizontal aleatoriamente
                if (Math.random() < 0.5) {
                    x += speed * 5;
                } else {
                    x -= speed * 5;
                }
            } else {
                // Movimiento lineal hacia el jugador
                if (x < playerX) {
                    x += speed * 2;
                } else if (x > playerX) {
                    x -= speed * 2;
                }
            }

            // Movimiento vertical hacia el jugador
            if (y < playerY) {
                y += speed * 2;
            } else if (y > playerY) {
                y -= speed * 2;
            }
            
            if(y > 690) {
            	die();
            }
        }
    }


    
    public void die() {
        isAlive = false; // Marcar al enemigo como muerto

    }
    
    public boolean isAlive() {
        return isAlive;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
        
    public void aumentarVelocidad() {
        this.speed *= 1.0234; // 
    }
    
    public void setLaunched(boolean launched) {
        this.launched = launched;
    }
}

