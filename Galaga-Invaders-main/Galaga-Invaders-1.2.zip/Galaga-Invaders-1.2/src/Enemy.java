import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random; // Importar la clase Random para generar números aleatorios
import javax.imageio.ImageIO;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Enemy {

    private int x, y;
    private int width, height;
    private float speed;
    private Color color;
    public static int levelSelect = 2;
    private List<BulletEnemy> bullets; // array de balas basicamente
    
    private boolean direccionDerecha = true; // Indica la dirección de movimiento
    private boolean isAlive = true; // Variable para el estado del enemigo
    
    private Image image;
    private Timer shootTimer; // Temporizador para disparar automáticamente
    private Random random; // Generador de números aleatorios

    public Enemy(int x, int y, int width, int height, float speed, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.color = color;        
        this.isAlive = true;
        this.bullets = new ArrayList<>();
        this.random = new Random(); // Inicializar el generador de números aleatorios

        try {
            image = ImageIO.read(getClass().getResource("/images/NaveInvasoraRoja.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("No se pudo cargar la imagen del enemigo.");
        }

        // Configurar el temporizador para disparar cada 2 segundos con un retraso aleatorio al inicio
        int initialDelay = random.nextInt(2000); // Retraso inicial aleatorio entre 0 y 2000 ms
        shootTimer = new Timer(2000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isAlive && random.nextDouble() < 0.7 && (levelSelect > 1 && levelSelect <= 5)) { // 70% de probabilidad de disparar
                    shoot();
                }
            }
        });
        shootTimer.setInitialDelay(initialDelay); // Establecer el retraso inicial aleatorio
        shootTimer.start(); // Iniciar el temporizador
    }
    
    public void draw(Graphics g) {
        if (isAlive) {
            if (image != null) {
                g.drawImage(image, x, y, width, height, null); // Dibuja la imagen del enemigo
                
                // Dibujar las balas
                for (BulletEnemy bullet : bullets) {
                    bullet.draw(g);
                }
                
            } else {
                // Si no se carga la imagen, dibujar un rectángulo de color como fallback
                g.setColor(color);
                g.fillRect(x, y, width, height);
            }
        }
    }
    
    public void update(List<Enemy> enemies) {
        if (isAlive) {
            if (direccionDerecha) {
                x += speed;
            } else {
                x -= speed;
            }
        
            // Actualizar todas las balas y eliminar las que están fuera de la pantalla
            List<BulletEnemy> bulletsToRemove = new ArrayList<>();
            for (BulletEnemy bullet : bullets) {
                bullet.update();
                if (bullet.getY() < 0) {
                    bulletsToRemove.add(bullet);
                }
                // Lógica para que en el caso de que colisione con el jugador le saque una vida
            }
            bullets.removeAll(bulletsToRemove);
        }
    }
    
    private void shoot() {
        // Crear una nueva bala y añadirla a la lista de balas
        BulletEnemy bullet = new BulletEnemy(x + width / 2 - 2, y + height, 5, 5, 8, Color.RED);
        bullets.add(bullet);
    }
    
    public void die() {
        isAlive = false; // Marcar al enemigo como muerto
        shootTimer.stop(); // Detener el temporizador cuando el enemigo muera
    }
    
    public boolean isAlive() {
        return isAlive;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public void cambiarDireccion(boolean aux) {
        direccionDerecha = !direccionDerecha;
    }
    
    public void descender() {
        y += 10; 
    }
    
    public void aumentarVelocidad() {
        this.speed *= 1.0234; // 
    }
}
